
//Exercicio 2 - A
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class GameEntry {

  private String nome;
  private int pontuacao;
  private LocalDate date;

  public GameEntry(String nome, int score, LocalDate date) {
    this.nome = nome;
    this.pontuacao = score;
    this.date = date;
  }

  public String getNome() {
    return nome;
  }

  public int getPontuacao() {
    return pontuacao;
  }

  public LocalDate getData() {
    return date;
  }

  @Override
  public String toString() {
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    String dataFormatada = date.format(formatter);
    return String.format("(%s, %d, %s)", nome, pontuacao, dataFormatada);
  }

}