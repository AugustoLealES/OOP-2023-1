
//Exercicio 2 - C
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class ScoresSerializacao extends Exception {

  private ScoresSerializacao(String message) {
    super(message);
  }

  private ScoresSerializacao() {
  }

  public static void ScoreCSV(GameScores g) throws ScoresSerializacao {

    try (BufferedWriter escrever = new BufferedWriter(new FileWriter("Scores.csv"))) {
      for (int i = 0; i < g.getNumScores(); i++) {
        GameEntry gameEntry = g.get(i);
        escrever.write(gameEntry.toString());
        escrever.newLine();
      }
    } catch (IOException e) {
      throw new ScoresSerializacao("Erro ao escrever arquivo Scores.csv");
    }

  }

}
