import java.io.IOException;
import java.time.LocalDate;

public class Testes {

  public static void main(String[] args) throws IOException, ScoresSerializacao {

    GameEntry teste1 = new GameEntry("Edson", 10, LocalDate.now());

    GameEntry teste2 = new GameEntry("Joao", 20, LocalDate.now());

    GameEntry teste3 = new GameEntry("Julio", 12, LocalDate.now());

    GameEntry teste4 = new GameEntry("Agustini", 56, LocalDate.now());

    GameEntry teste5 = new GameEntry("Roland", 12, LocalDate.now());

    GameEntry teste6 = new GameEntry("Rafael", 28, LocalDate.now());

    GameEntry teste7 = new GameEntry("Isabel", 29, LocalDate.now());

    GameEntry teste8 = new GameEntry("Fabiano", 345, LocalDate.now());
    GameEntry teste9 = new GameEntry("Anderson", 345, LocalDate.now());
    GameEntry teste10 = new GameEntry("Giraffa", 345, LocalDate.now());

    GameEntry teste11 = new GameEntry("Bernardo", 11, LocalDate.now());
    // Remover o pior e adicionar esse no lugar(teste)

    GameScores scores = new GameScores(10);

    System.out.println("(TESTE)Adicionando os Jogadores e seus Respectivos dados na lista!");

    scores.add(teste1);
    scores.add(teste2);
    scores.add(teste3);
    scores.add(teste4);
    scores.add(teste5);
    scores.add(teste6);
    scores.add(teste7);
    scores.add(teste8);
    scores.add(teste9);
    scores.add(teste10);
    scores.add(teste11);

    System.out.println("");

    System.out.println("(TESTE)Imprimindo Método toString da interface Scores!");
    System.out.println(scores.toString());

    System.out.println("");

    System.out.println("(TESTE) imprimindo métodos");
    System.out.println("");
    System.out.println("Media Scores: " + scores.getAvgScores());
    System.out.println("");
    System.out.println("Capacidade da Lista Scores(setada no construtor): " +
        scores.getCapacity());
    System.out.println("");
    System.out.println("Contagem de Scores que existem na lista: " + scores.getNumScores());
    System.out.println("");

    System.out.println("O Score que esta na posicao setada(EXEMPLO Num 4):" + scores.get(4));

    ScoresSerializacao.ScoreCSV(scores);
  }
}