
//Exercicio 2 -  B
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class GameScores implements Scores {

  private int capacidade;

  public GameScores(int capacidade) {
    this.capacidade = capacidade;
  }

  private List<GameEntry> score = new ArrayList<>();

  @Override
  public String toString() {

    StringBuilder sb = new StringBuilder();
    sb.append("GamesScores { ");
    for (GameEntry entry : score) {
      sb.append("(");
      sb.append(entry.getNome()).append(",");
      sb.append(entry.getPontuacao()).append(",");
      sb.append(entry.getData());
      sb.append(")");
      sb.append(",");

    }
    if (!score.isEmpty()) {
      sb.setLength(sb.length() - 1);
    }

    sb.append(" }");
    return sb.toString();
  }

  @Override
  public GameEntry get(int i) {
    return score.get(i);
  }

  @Override
  public double getAvgScores() {
    double soma = 0;

    for (GameEntry gameEntry : score) {
      soma += gameEntry.getPontuacao();
    }

    double average = soma / getNumScores();

    return average;

  }

  @Override
  public int getCapacity() {
    return capacidade;
  }

  @Override
  public int getNumScores() {
    int contador = 0;
    for (GameEntry game : score) {
      if (score.size() >= 0) {
        contador++;
      }
    }
    return contador;
  }

  @Override
  public boolean add(GameEntry e) {
    if (score.size() < capacidade) {
      score.add(e);
      Collections.sort(score, Comparator.comparingDouble(GameEntry::getPontuacao).reversed());
      return true;
    } else if (e.getPontuacao() > getLowestScore()) {
      score.remove(score.size() - 1);
      score.add(e);
      Collections.sort(score, Comparator.comparingDouble(GameEntry::getPontuacao).reversed());
      return true;
    }
    return false;
  }

  private double getLowestScore() {
    if (score.isEmpty()) {
      return 0.0;
    }
    return score.get(score.size() - 1).getPontuacao();
  }

}