//Exercicio 2 - B
public interface Scores {

  /**
   * Retorna uma string representando o objeto
   * Formato: [(<name>, <score>, <date>), (<name>, <score>, <date>) ...] *
   * Exemplo: [(John, 10, 10/04/2023), (Carol, 5, 01/02/2022)]
   */
  String toString();

  /**
   * Adiciona um novo score se ele for grande o suficiente
   * Retorna verdadeiro se foi adicionado, falso caso contrário
   */
  boolean add(GameEntry e);

  /** Retorna o score na posição i */
  GameEntry get(int i);

  /** Retorna a capacidade máxima da coleção */
  int getCapacity();

  /** Retorna o número de scores armazenados */
  int getNumScores();

  /** Retorna a média dos scores armazenados */
  double getAvgScores();
}
