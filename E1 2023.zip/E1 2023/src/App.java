import java.util.*;

public class App {

    static Scanner sc = new Scanner(System.in);

    static GaragemLocomotivas garagemLocomotivas = new GaragemLocomotivas();
    static GaragemVagoes garagemVagoes = new GaragemVagoes();
    static PatioComposicoes patioComposicoes = new PatioComposicoes();

    public static void main(String[] args) throws Exception {
        garagemLocomotivas.adicionar(new Locomotiva(1, 100, 5));
        garagemLocomotivas.adicionar(new Locomotiva(2, 200, 10));
        garagemLocomotivas.adicionar(new Locomotiva(3, 300, 15));

        garagemVagoes.adicionar(new Vagao(1, 10));
        garagemVagoes.adicionar(new Vagao(2, 20));
        garagemVagoes.adicionar(new Vagao(3, 30));
        menu();
        sc.close();
    }

    public static void menu() {

        System.out.println("Digite o número da opção abaixo:");
        System.out.println("1 - Criar uma composição");
        System.out.println("2 - Editar uma composição");
        System.out.println("3 - Listar todas as composições já criadas (todos as composições que estão no pátio)");
        System.out.println("4 - Desfazer uma composição");
        System.out.println("5 - Encerrar o programa");
        int option = sc.nextInt();
        System.out.println();

        switch (option) {
            case 1:
                criarComposicao(garagemLocomotivas, garagemVagoes, patioComposicoes);
                System.out.println();
                break;
            case 2:
                editarComposicao(garagemLocomotivas, garagemVagoes, patioComposicoes);
                System.out.println();
                break;
            case 3:
                listarComposicoes();
                System.out.println();
                break;
            case 4:
                removerComposicao();
                System.out.println();
                break;
            case 5:
                System.exit(0);
                System.out.println();
                break;
            default:
                System.out.println("Você digitou uma opção inválida, por favor, digite um número de 1 a 4");
                break;
        }
        menu();
    }

    // Opção 1: Criar Composição
    public static void criarComposicao(GaragemLocomotivas garagemLocomotivas, GaragemVagoes garagemVagoes,
            PatioComposicoes patioComposicoes) {
        System.out.println("Digite o número do ID da composição: (Maior que 0)");
        int idComposicao;
        while (true) {
            idComposicao = sc.nextInt();
            if (idComposicao > 0) {
                break;
            } else {
                System.out.println("Digite um valor maior que zero: ");
            }
        }

        System.out.println("Digite o ID da primeira locomotiva da composição: ");
        int idLocomotiva = sc.nextInt();

        Composicao composicao = new Composicao(idComposicao, garagemLocomotivas.locomotivaSai(idLocomotiva));
        patioComposicoes.composicaoEntra(composicao);
        System.out.println(composicao);
    }

    // Opção 2: Editar Composição
    public static void editarComposicao(GaragemLocomotivas garagemLocomotivas, GaragemVagoes garagemVagoes,
            PatioComposicoes patioComposicoes) {
        System.out.println("Digite o número do ID da composição:");
        int idComposicao = sc.nextInt();
        for (int i = 0; i < patioComposicoes.qtdComposicoes(); i++) {
            if (idComposicao == patioComposicoes.getComposicao(i).getId()) {
                Composicao composicao = patioComposicoes.getComposicao(i);

                System.out.println("\nDigite a opção desejada:");
                System.out.println("1 - Inserir uma locomotiva (informar identificador) respeitando restricoes");
                System.out.println("2 - Inserir um vagão (informar identificador) respeitando restricoes");
                System.out.println("3 - Remover o último elemento da composição");
                System.out.println("4 - Listar locomotivas livres");
                System.out.println("5 - Listar vagões livres");
                System.out.println("6 - Encerrar a edição da composição");
                int option = sc.nextInt();
                System.out.println();

                switch (option) {
                    case 1:
                        insereLocomotiva(composicao, garagemLocomotivas, patioComposicoes);
                        System.out.println();
                        break;
                    case 2:
                        insereVagao(composicao, garagemVagoes, patioComposicoes);
                        System.out.println();
                        break;
                    case 3:
                        removerUltimoElementoComposicao(composicao);
                        System.out.println();
                        break;
                    case 4:
                        listarLocomotivasLivres();
                        System.out.println();
                        break;
                    case 5:
                        listarVagoesLivres();
                        System.out.println();
                        break;
                    case 6:
                        System.out.println("Edição encerrada.");
                        System.out.println();
                        menu();
                        break;
                    default:
                        System.out.println("Você digitou uma opção inválida");
                        menu();
                        break;
                }
            } else {
                System.out.println("Erro, composição não encontrada\n");
            }

        }

    }

    // Opção 2.1: Inserir Locomotiva
    public static void insereLocomotiva(Composicao composicao, GaragemLocomotivas garagemLocomotivas,
            PatioComposicoes patioComposicoes) {
        boolean aux = false;
        System.out.println("Informe o ID da locomotiva que você deseja inserir: ");
        int idLocomotiva = sc.nextInt();
        for (int i = 0; i < garagemLocomotivas.getQtdLocomotivasGaragem(); i++) {
            if (idLocomotiva == garagemLocomotivas.getLocomotiva(i).getId()) {
                Locomotiva locomotiva = garagemLocomotivas.locomotivaSai(idLocomotiva);
                composicao.engataLocomotiva(locomotiva);
                System.out.println(composicao);
                aux = true;
                break;
            } else {
                aux = false;
            }
        }
        if (aux == false) {
            System.out.println("Locomotiva não encontrada ou já engatada");
        }
    }

    // Opção 2.2: Inserir Vagão
    public static void insereVagao(Composicao composicao, GaragemVagoes garagemVagoes,
            PatioComposicoes patioComposicoes) {
        boolean aux = false;
        System.out.println("Informe o ID do vagão que você deseja inserir: ");
        int idVagao = sc.nextInt();
        for (int i = 0; i < garagemVagoes.getQtdVagoesGaragem(); i++) {
            if (idVagao == garagemVagoes.getVagao(i).getId()) {
                Vagao vagao = garagemVagoes.remover(idVagao);
                composicao.engataVagao(vagao);
                System.out.println(composicao);
                aux = true;
                break;
            } else {
                aux = false;
            }
        }
        if (aux == false) {
            System.out.println("Vagão não encontrado ou já engatado");
        }
    }

    // Opção 2.3: Remover Último Elemento
    public static void removerUltimoElementoComposicao(Composicao composicao) {
        if (composicao.getQtdLocomotivasComposicao() == 1) {
            System.out.println("Impossível remover última locomotiva. Desfaça a composição.");
        }
        if (composicao.getQtdVagoesComposicao() != 0) {
            Vagao vagao = composicao.desengataVagao();
            garagemVagoes.adicionar(vagao);
            System.out.println("Último vagão desengatado");
        } else {
            if (composicao.getQtdLocomotivasComposicao() > 1) {
                Locomotiva locomotiva = composicao.desengataLocomotiva();
                garagemLocomotivas.adicionar(locomotiva);
                System.out.println("Última locomotiva desengatada");
            }
        }
    }

    // Opção 2.4: Listar Locomotivas Livres
    public static void listarLocomotivasLivres() {
        System.out.println("\nTodas locomotivas que estão na garagem de locomotivas: ");
        for (int index = 0; index < garagemLocomotivas.getQtdLocomotivasGaragem(); index++) {
            if (garagemLocomotivas.getQtdLocomotivasGaragem() > 0) {
                Locomotiva locomotiva = garagemLocomotivas.getLocomotiva(index);
                System.out.println(locomotiva);
            } else {
                System.out.print("Não há locomotivas na garagem\n");
            }
        }
    }

    // Opção 2.5: Listar Vagões Livres
    public static void listarVagoesLivres() {
        System.out.println("\nTodos os vagões que estão na garagem de vagões:");
        for (int i = 0; i < garagemVagoes.getQtdVagoesGaragem(); i++) {
            if (garagemVagoes.getQtdVagoesGaragem() > 0) {
                Vagao vagao = garagemVagoes.getVagao(i);
                System.out.println(vagao);
            } else {
                System.out.print("Não há vagões na garagem");
            }
        }
    }

    // Opção 3: Listar Composições
    public static void listarComposicoes() {
        System.out.println("Todos as composições que estão no pátio de composições:");
        for (int i = 0; i < patioComposicoes.qtdComposicoes(); i++) {
            if (patioComposicoes.qtdComposicoes() > 0) {
                Composicao composicao = patioComposicoes.getComposicao(i);
                System.out.println(composicao);
            }
        }
        if (patioComposicoes.qtdComposicoes() == 0) {
            System.out.print("Não há composições no pátio de composições\n");
        }
    }

    // Opção 4: Desfazer Composição
    public static void removerComposicao() {
        boolean aux = false;
        System.out.println("Digite o ID de uma composição que você deseja excluir: ");
        int idComposicao = sc.nextInt();
        for (int i = 0; i < patioComposicoes.qtdComposicoes(); i++) {
            if (idComposicao == patioComposicoes.getComposicao(i).getId()) {
                Composicao composicao = patioComposicoes.getComposicao(i);

                while (composicao.getQtdLocomotivasComposicao() != 0) {
                    Locomotiva locomotiva = composicao.desengataLocomotiva();
                    garagemLocomotivas.adicionar(locomotiva);
                }
                while (composicao.getQtdVagoesComposicao() != 0) {
                    Vagao vagao = composicao.desengataVagao();
                    garagemVagoes.adicionar(vagao);
                }

                patioComposicoes.remove(composicao);
                aux = true;
            }
        }
        if (aux == false) {
            System.out.println("Composição não encontrada");
        } else {
            System.out.println("Composição removida com sucesso!");
        }
    }

}
