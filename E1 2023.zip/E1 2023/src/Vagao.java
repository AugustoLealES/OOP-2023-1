public class Vagao {

    private int id;
    private double pesoMax;
    private Composicao composicao;

    public Vagao(int id, double pesoMax) {
        this.id = id;
        this.pesoMax = pesoMax;
        this.composicao = null;
    }

    public Composicao getComposicao() {
        return composicao;
    }

    public void setComposicao(Composicao composicao) {
        this.composicao = composicao;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getPesoMax() {
        return pesoMax;
    }

    public void setPesoMax(double pesoMax) {
        this.pesoMax = pesoMax;
    }

    public boolean livre() {
        return composicao == null;
    }

    @Override
    public String toString() {
        return "Vagao [id = " + id + ", pesoMax = " + pesoMax + ", composicao = " + composicao + "]";
    }

}
