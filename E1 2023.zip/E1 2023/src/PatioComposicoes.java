import java.util.ArrayList;

public class PatioComposicoes {
    private ArrayList<Composicao> composicoes;

    public PatioComposicoes() {
        composicoes = new ArrayList<>();
    }

    public void composicaoEntra(Composicao composicao) {
        composicoes.add(composicao);
    }

    public Composicao getComposicao(int index) {
        return composicoes.get(index);
    }

    public int qtdComposicoes() {
        return composicoes.size();
    }

    public void remove(Composicao composicao) {
        composicoes.remove(composicao);
    }

    public Composicao[] listar() {
        return composicoes.toArray(new Composicao[composicoes.size()]);
    }

    @Override
    public String toString() {
        StringBuilder s = new StringBuilder();
        for (var composicao : composicoes) {
            s.append(composicao);
            s.append(System.lineSeparator());
        }
        return s.toString();
    }

}
