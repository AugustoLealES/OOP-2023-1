public class Locomotiva {
    private int id;
    private double pesoMax;
    private int maxVagoes;
    private Composicao composicao;

    public Locomotiva(int id, double pesoMax, int maxVagoes) {
        this.id = id;
        this.pesoMax = pesoMax;
        this.maxVagoes = maxVagoes;
        this.composicao = null;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getPesoMax() {
        return pesoMax;
    }

    public void setPesoMax(double pesoMax) {
        this.pesoMax = pesoMax;
    }

    public int getMaxVagoes() {
        return maxVagoes;
    }

    public void setMaxVagoes(int maxVagoes) {
        this.maxVagoes = maxVagoes;
    }

    public boolean livre() {
        return composicao == null;
    }

    public void setComposicao(Composicao composicao) {
        this.composicao = composicao;
    }

    @Override
    public String toString() {
        return "Locomotiva [id=" + id + ", pesoMax=" + pesoMax + ", maxVagoes=" + maxVagoes + ", composicao="
                + composicao + "]";
    }

}
