import java.util.ArrayList;

public class GaragemVagoes {
    private ArrayList<Vagao> vagoes;

    public GaragemVagoes() {
        vagoes = new ArrayList<>();
    }

    public void adicionar(Vagao vagao) {
        vagoes.add(vagao);
    }

    public Vagao remover(int id) {
        for (int i = 0; i < vagoes.size(); i++) {
            if (vagoes.get(i).getId() == id) {
                Vagao vagao = vagoes.remove(i);
                return vagao;
            }
        }
        return null;
    }

    public Vagao[] listar() {
        return vagoes.toArray(new Vagao[vagoes.size()]);
    }

    public int getQtdVagoesGaragem() {
        return vagoes.size();
    }

    public Vagao getVagao(int i) {
        return vagoes.get(i);
    }

    public String toString() {
        StringBuilder s = new StringBuilder();
        for (var vagao : vagoes) {
            s.append(vagao.toString());
            s.append(System.lineSeparator());
        }
        return s.toString();
    }
}
