import java.util.ArrayList;

public class GaragemLocomotivas {
    private ArrayList<Locomotiva> locomotivas;

    public GaragemLocomotivas() {
        locomotivas = new ArrayList<>();
    }

    public void adicionar(Locomotiva l) {
        locomotivas.add(l);
    }

    public Locomotiva locomotivaSai(int id) {
        for (int i = 0; i < locomotivas.size(); i++) {
            if (locomotivas.get(i).getId() == id) {
                Locomotiva locomotiva = locomotivas.remove(i);
                return locomotiva;
            }
        }
        return null;
    }

    // public ArrayList<Locomotiva> listar() {
    // return Collections.unmodifiableList(vagoes);
    // }

    public int getQtdLocomotivasGaragem() {
        return locomotivas.size();
    }

    public Locomotiva getLocomotiva(int index) {
        return locomotivas.get(index);
    }

    public Locomotiva[] listar() {
        return locomotivas.toArray(new Locomotiva[locomotivas.size()]);
    }

    @Override
    public String toString() {
        StringBuilder s = new StringBuilder();
        for (var locomotiva : locomotivas) {
            s.append(locomotiva);
            s.append(System.lineSeparator());
        }
        return s.toString();
    }

}