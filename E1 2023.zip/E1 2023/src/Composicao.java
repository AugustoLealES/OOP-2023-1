import java.util.ArrayList;

public class Composicao {
    private int id;
    private ArrayList<Vagao> vagoes;
    private ArrayList<Locomotiva> locomotivas;

    public Composicao(int id, Locomotiva locomotiva) {
        vagoes = new ArrayList<>();
        locomotivas = new ArrayList<>();
        this.engataLocomotiva(locomotiva);
        this.id = id;
    }
    
    public Locomotiva getLocomotiva(int posicao){
        if (posicao < 0 || posicao >= locomotivas.size()) {
            return null;
        }
        return locomotivas.get(posicao);
    }


    public Vagao getVagao(int posicao){
        if (posicao < 0 || posicao >= vagoes.size()) {
            return null;
        }
        return vagoes.get(posicao);
    }

    public boolean engataLocomotiva(Locomotiva locomotiva) {

        if (vagoes.size() > 0) {
            return false;
        }
        locomotivas.add(locomotiva);
        locomotiva.setComposicao(this);
        return true;
    }

    public boolean engataVagao(Vagao vagao) {
        if (vagoes.size() == calculaMaxVagoes()) {
            return false;
        }

        if (pesoDosVagoes() >= calculaPesoMaxLocomotivas()) {
            return false;
        }

        vagoes.add(vagao);
        vagao.setComposicao(this);
        return true;
    }

    public Locomotiva desengataLocomotiva() {
        if (locomotivas.size() <= 0) {
            return null;
        }
        Locomotiva aux = locomotivas.remove(locomotivas.size() - 1);
        aux.setComposicao(null);
        return aux;
    }

    public Vagao desengataVagao() {
        if (vagoes.size() <= 0) {
            return null;
        }
        Vagao aux = vagoes.remove(vagoes.size() - 1);
        aux.setComposicao(null);
        return aux;
    }

    // Verifica a quantidade máxima de vagões que x locomotivas podem carregar.
    private int calculaMaxVagoes() {
        double max = 0;
        double fator = 1.0;
        for (Locomotiva l : locomotivas) {
            max = max + (l.getMaxVagoes() * fator);
            fator = fator * 0.9;
        }
        return (int) max;
    }

    private double calculaPesoMaxLocomotivas() {
        double peso = 0.0;
        for (Locomotiva l : locomotivas) {
            peso += l.getPesoMax();
        }

        return peso;
    }

    private double pesoDosVagoes() {
        double peso = 0.0;
        for (Vagao v : vagoes) {
            peso += v.getPesoMax();
        }
        return peso;
    }

    public int getId() {
        return id;
    }

    public int getQtdVagoesComposicao() {
        int qtd = vagoes.size();
        return qtd;
    }

    public int getQtdLocomotivasComposicao() {
        int qtd = locomotivas.size();
        return qtd;
    }

    public String toString() {
        String aux = "Composição: " + id + " ";
        for (Locomotiva l : locomotivas) {
            aux += "[Locomotiva" + l.getId() + "]+";
        }
        for (Vagao v : vagoes) {
            aux += "[Vagão" + v.getId() + "]+";
        }
        return aux;
    }

}
