public class Marte extends ElementoBasico {
    

    public Marte(String id, int linInicial, int colInicial, Tabuleiro tabuleiro) {
        super(id, "marte.jpg", linInicial, colInicial, tabuleiro);
        
    }

   

    @Override
    public void acao(ElementoBasico outro) {
          
        
    }
}
