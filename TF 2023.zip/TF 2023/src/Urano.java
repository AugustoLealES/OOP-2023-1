public class Urano extends ElementoBasico {
    

    public Urano(String id,  int linInicial, int colInicial, Tabuleiro tabuleiro) {
        super(id, "Urano.png", linInicial, colInicial, tabuleiro);
        
    }

   

    @Override
    public void acao(ElementoBasico outro) {
          
        
    }
}
