public class Saturno extends ElementoBasico {
    

    public Saturno(String id,  int linInicial, int colInicial, Tabuleiro tabuleiro) {
        super(id, "saturno.png", linInicial, colInicial, tabuleiro);
        
    }

   

    @Override
    public void acao(ElementoBasico outro) {
          
        
    }
}
