public class Netuno extends ElementoBasico {
    

    public Netuno(String id, int linInicial, int colInicial, Tabuleiro tabuleiro) {
        super(id, "netuno.jpg", linInicial, colInicial, tabuleiro);
        
    }

   

    @Override
    public void acao(ElementoBasico outro) {
          
        
    }
}
